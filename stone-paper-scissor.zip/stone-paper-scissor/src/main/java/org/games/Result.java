package org.games;

public enum Result {
    WIN("Wins"),
    LOSE("Loses"),
    DRAW("Draw");

    private String value;

    Result(String value) {
    }
}
