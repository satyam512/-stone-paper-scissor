package org.games;

public interface InputProvider {
    Move makeMove();
}
